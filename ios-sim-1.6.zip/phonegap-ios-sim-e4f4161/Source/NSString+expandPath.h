/*
 * See the LICENSE file for the license on the source code in this file.
 */

#import <Foundation/Foundation.h>

@interface NSString (ExpandPath)

- (NSString *)expandPath;

@end
