int nsvfprintf (FILE *stream, NSString *format, va_list args);
int nsfprintf (FILE *stream, NSString *format, ...);
int nsprintf (NSString *format, ...);
